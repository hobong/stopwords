package scenarios

import io.gatling.core.Predef._
import io.gatling.http.Predef._
import config.Config._

import scala.util.Random

object Reading10KpagePublishedATScenario {


  val API_VER = "v2"

  val TermID = csv(s"data\\ReadingPagesAT\\${env}pages10K.csv").circular

  val scn = scenario("Read10KPages") //.during(300 seconds) //.feed(TermID)

  .group("Read10KPages") {
    exec(http("Read Concept")
      .get("/v2/appterminologies/ROX32426790097180527") // ROX32426790097180527 -> Label of term is "Target" in NePALs
      .headers(headers_ADMIN))

      .pause(0, 1)
      .exec(http("pages1")
        .get("/v2/appterminologies/ROX32426790097180527/published/concepts?page=1&per_page=100&fields=pref_label")

        .headers(headers_ADMIN)
        .resources(http("pages2")
          .get("/v2/appterminologies/ROX32426790097180527/published/concepts?page=2&per_page=100&fields=pref_label")
          .headers(headers_ADMIN),
          http("pages3")
            .get("/v2/appterminologies/ROX32426790097180527/published/concepts?page=3&per_page=100&fields=pref_label")
            .headers(headers_ADMIN))
      )

      //emulate user wants other than next pages (from results possible)
      .randomSwitch(
        50.0 -> {
          pause(0, 1)
          val rp1 = Random.nextInt(50)
          val rp2 = rp1 + 1

          exec(http("Read10KPages_pagesRand")
            .get(s"/v2/appterminologies/ROX32426790097180527/published/concepts?page=${rp1}&per_page=100&fields=pref_label")
            .headers(headers_ADMIN))
            .exec(http("Read10KPages_pages")
              .get(s"/v2/appterminologies/ROX32426790097180527/published/concepts?page=${rp2}&per_page=100&fields=pref_label")
              .headers(headers_ADMIN))

        },
                50.0 -> {
          pause(0, 1)
        }

      )
  }





}