/* Scenario used to retest improvement RTSIVD-30 */

package scenarios

import requests.refterminology.PostRefTerminologyContentRequest
import io.gatling.core.Predef.scenario

object PostRefTerminologyContentScenario {
  val postRefTerminologyContentScenario = scenario("Post Reference Terminology Content")
    .exec(PostRefTerminologyContentRequest.postRefTerminologyContent)

}