package scenarios

import requests.ReadMetadataStatusesRequest
import io.gatling.core.Predef._
import requests.refterminology.{ReadConceptDetailsRequest, ReadConceptLabelsRequest, ReadMetadataRequest}
import requests.search.SearchUriRequest

object OpenConceptEntityScenario {
  val openConceptEntityScenario = scenario("Open Concept Entity")
    .exec(ReadConceptDetailsRequest.readConceptDetails)
    .pause(5)
    .exec(ReadConceptLabelsRequest.readConceptLabels)
    .pause(5)
    .exec(ReadMetadataRequest.readMetadata)
    .pause(5)
    .exec(ReadMetadataStatusesRequest.readMetadataStatuses)
    .pause(5)
    .exec(SearchUriRequest.searchUri)
}
