package scenarios

import io.gatling.core.Predef._
import io.gatling.http.Predef._

object Reading10KpageATScenario {

	val httpProtocol = http
		.baseUrl("https://ontology-services-dev.roche.com")
		.inferHtmlResources()
		.acceptHeader("application/json, text/plain, */*")
		.acceptEncodingHeader("gzip, deflate")
		.acceptLanguageHeader("en-US,en;q=0.9")
		.userAgentHeader("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36")

	val headers_0 = Map(
		"Sec-Fetch-Dest" -> "empty",
		"Sec-Fetch-Mode" -> "cors",
		"Sec-Fetch-Site" -> "same-origin",
		//  "Authorization" -> "Basic cnRzMnRzdDE6ZEQyM3Y2NVpoZlJ0OQ==") //ADMIN
		"Authorization" -> "Basic cnRzMnRzdDI6ZEQyM3Y2NVpoZlJ0OQ==") //CURATOR
	// "Authorization" -> "Basic cnRzMnRzdDM6ZEQyM3Y2NVpoZlJ0OQ==") //USER


	val scn = scenario("Read10KPages")
		.exec(http("Read10KPages_0")
			.get("/rts2-api/int/applications")
			.headers(headers_0))
		.pause(19)
		.exec(http("Read10KPages_Concept")
			.get("/rts2-api/int/appterminologies/ROX32426790097180527")       // ROX32426790097180527 -> Label of term is "Target" in NePALs
			.headers(headers_0))
		.pause(13)
		.exec(http("Read10KPages_pages")
			.get("/rts2-api/int/appterminologies/ROX32426790097180527/concepts?topConcepts=true&fields=id,pref_label,status,has_children&page=1&per_page=10000")
			.headers(headers_0)
			.resources(http("Read10KPages_pages")
			.get("/rts2-api/int/appterminologies/ROX32426790097180527/concepts?topConcepts=true&fields=id,pref_label,status,has_children&page=3&per_page=10000")
			.headers(headers_0),
            http("Read10KPages_pages")
			.get("/rts2-api/int/appterminologies/ROX32426790097180527/concepts?topConcepts=true&fields=id,pref_label,status,has_children&page=2&per_page=10000")
			.headers(headers_0)))

}