package scenarios

import io.gatling.core.Predef._
import requests.refterminology.{ReadAppTermRefsRequest, ReadConceptBroaderRequest, ReadConceptNarrower, ReadConceptXRef}

object OpenTabScenario {
  val openTabScenario = scenario("Open tabs scenario")
    .exec(ReadConceptXRef.readConceptXRef)
    .pause(5)
    .exec(ReadConceptBroaderRequest.readBroader)
    .pause(5)
    .exec(ReadConceptNarrower.readNarrower)
    .pause(5)
    .exec(ReadAppTermRefsRequest.readAppTermRefs)
}
