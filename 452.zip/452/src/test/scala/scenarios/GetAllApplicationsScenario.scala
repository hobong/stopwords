/* Scenario for testing task RTSIV-49 */

package scenarios

import requests.application.ReadAllApplicationsByUser
import io.gatling.core.Predef._
import scala.concurrent.duration._

object GetAllApplicationsScenario {
  val getApplicationsUser = scenario("Get list of all applications")
    .repeat(1, "repeat_counter") { pause(5 seconds).exec(ReadAllApplicationsByUser.getApplicationsUser) }
}