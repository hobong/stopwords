package scenarios

import requests.search.SearchUriRequest
import requests.appterminology.{TransferConceptRequest, ReadConceptsRequest}
import io.gatling.core.Predef.scenario
import scala.concurrent.duration._

object AddConceptsListScenario {
  val addConceptsListScenario = scenario("Add Concepts List")
    .exec(SearchUriRequest.searchUri)
    .pause(2 seconds)
    .exec(TransferConceptRequest.transferConcept)
    .pause(2 seconds)
    .exec(ReadConceptsRequest.readConcepts)
}
