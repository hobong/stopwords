package scenarios

import io.gatling.core.Predef.scenario
import requests.variables.{CreateVariableRequest, ReadDomainDetailsRequest, ReadDomainsListRequest, ReadVariablesDetailsRequest}
import scala.concurrent.duration._

object CreateVariableScenario {
  val createVariableScenario = scenario ("Create Variable")
    .exec(ReadDomainDetailsRequest.readDomainDetails)
    .pause(2 seconds)
    .exec(CreateVariableRequest.createVariable)
    .pause(5 seconds)
    .exec(ReadVariablesDetailsRequest.readVariables)
    .pause(2 seconds)
    .exec(ReadDomainsListRequest.readDomainsList)
}