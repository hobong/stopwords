/*
The following steps are executed:
1. ReadMasterTermRequest
2. ReadSPVariableRequest
3. OpenApplicationDomainsRequest
4. OpenDomainVariablesRequest
 */


package scenarios

object OpenVariableScenario {

}
