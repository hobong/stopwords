package scenarios

import io.gatling.core.Predef.scenario
import requests.search.SearchSparqlRequest

object SearchSparqlScenario {
  val searchSparqlScenario = scenario("Use Search/sparql").exec(SearchSparqlRequest.search_sparql)
}