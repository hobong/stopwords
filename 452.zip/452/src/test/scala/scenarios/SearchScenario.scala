package scenarios

import io.gatling.core.Predef.scenario
import requests.search.SearchRequest

object SearchScenario {
  val searchScenario = scenario("Use /search").exec(SearchRequest.search)
}
