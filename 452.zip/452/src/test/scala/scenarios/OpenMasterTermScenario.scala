package scenarios

import io.gatling.core.Predef._
import requests.refterminology.{ReadMasterTermRequest, ReadTopconceptsRequest}

object OpenMasterTermScenario {
  val openMasterTermScenario = scenario("Open terminology node")
    .exec(ReadMasterTermRequest.readMasterTerm)
    .pause(5)
    .exec(ReadTopconceptsRequest.readTopconcepts)
    .pause(5)
}
