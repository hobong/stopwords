package scenarios

object GetVariableOrderedTrueScenario {
  // take variables when "ordered": true

}
