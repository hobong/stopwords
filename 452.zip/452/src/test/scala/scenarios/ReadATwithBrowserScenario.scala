package scenarios


/*
// RTSIVD-452
20 concurrent users reading via the RTS Browser
Open an Application
Open first AT in Application
Open first concept in AT
Open second concept in AT
Search for a concept via text search and open the first hit
*/
// M.P. Almost directly transferred from sessions caught with fiddler while using RTS Browser
// DEV data hardcoded
// TODO: parametrization


import com.typesafe.scalalogging.Logger
import io.gatling.core.Predef.{scenario, _}
import io.gatling.http.Predef._
import config.Config._
import requests.external._
import io.gatling.core.Predef._

import scala.concurrent.duration._


object ReadATwithBrowserScenario {

  def testDataSrc: String = s"data\\${env}AppTerm.csv"

  val AppTermID = csv(testDataSrc).circular
  Logger("CONFIG").info(s"test-data source for ReadATwithBrowserScenario ===> ${testDataSrc}")

  val scnDEV = scenario("ReadATwithBrowserDEV").feed(AppTermID)
    .exec(http("ReadATwithBrowser request_0")
      //   .get("/int/applications/${terminology_id}")
      .get("/int/applications/ROX37977120443872951")
      .headers(headers_ADMIN))
    .pause(1 seconds, 2 seconds)

    .exec(http("ReadATwithBrowser request_1")
      //      .get("/int/applications/${TERMINOLOGY_ID}/terminologies")
      .get("/int/applications/ROX37977120443872951/terminologies")
      .headers(headers_ADMIN))
    .pause(1 seconds, 3 seconds)
    .exec(http("ReadATwithBrowser request_2")
      .get("/int/appterminologies/ROX37977120443872986/concepts?topConcepts=true&fields=id,pref_label,status,has_children")
      .headers(headers_ADMIN))
    .pause(1 seconds, 3 seconds)
    .exec(http("ReadATwithBrowser request_3")
      .get("/int/search/uri/ROX37977120443872968")
      .headers(headers_ADMIN))
    .exec(http("ReadATwithBrowser request_4")
      .get("/int/appterminologies/ROX37977120443872986")
      .headers(headers_ADMIN))
    .exec(http("ReadATwithBrowser request_5")
      .get("/int/refterminologies/ROX37977120443872964/concepts/ROX37977120443872968")
      .headers(headers_ADMIN))
    .exec(http("ReadATwithBrowser request_6")
      .get("/int/refterminologies/ROX37977120443872964")
      .headers(headers_ADMIN))
    .exec(http("ReadATwithBrowser request_7")
      .get("/int/refterminologies/ROX37977120443872964/concepts/ROX37977120443872968/xrefs")
      .headers(headers_ADMIN))
    .exec(http("ReadATwithBrowser request_8")
      .get("/int/refterminologies/ROX37977120443872964/concepts/ROX37977120443872968/labels")
      .headers(headers_ADMIN))
    .exec(http("ReadATwithBrowser request_9")
      .get("/int/refterminologies/ROX37977120443872964/metadata")
      .headers(headers_ADMIN))
    .pause(5 seconds, 10 seconds)
    .exec(http("ReadATwithBrowser request_10")
      .get("/int/search/uri/ROX37977120443872970")
      .headers(headers_ADMIN))
    .exec(http("ReadATwithBrowser request_11")
      .get("/int/refterminologies/ROX37977120443872964")
      .headers(headers_ADMIN))
    .exec(http("ReadATwithBrowser request_12")
      .get("/int/refterminologies/ROX37977120443872964/concepts/ROX37977120443872970")
      .headers(headers_ADMIN))
    .exec(http("ReadATwithBrowser request_13")
      .get("/int/refterminologies/ROX37977120443872964/concepts/ROX37977120443872970/labels")
      .headers(headers_ADMIN))
    .exec(http("ReadATwithBrowser request_14")
      .get("/int/appterminologies/ROX37977120443872986/concepts/ROX37977120443872970/applicableLabels")
      .headers(headers_ADMIN))
    .exec(http("ReadATwithBrowser request_15")
      .get("/int/refterminologies/ROX37977120443872964/concepts/ROX37977120443872970/xrefs")
      .headers(headers_ADMIN))
    .pause(5 seconds, 10 seconds)

    .exec(http("ReadATwithBrowser /int/search/applications")
      .post("/int/search/applications")
      .headers(headers_ADMIN)
      .body(StringBody(
        //"app_id": "${terminology_id}",
        //
        """{
          |"app_id": "ROX32411421720461885",
          |"page": 1,
          |"per_page": 100,
          |"text": "etykieta"
					|}""".stripMargin)).asJson
    )

    .pause(1 seconds)

    .exec(http("ReadATwithBrowser request_17")
      .get("/int/appterminologies/ROX37977120443872986/concepts/ROX37977120443872972/classpaths")
      .headers(headers_ADMIN))
    .exec(http("request_18")
      .get("/int/appterminologies/ROX37977120443872986/concepts/ROX37977120443872972")
      .headers(headers_ADMIN))
    .exec(http("ReadATwithBrowser request_19")
      .get("/int/search/uri/ROX37977120443872972")
      .headers(headers_ADMIN))
    .exec(http("ReadATwithBrowser request_20")
      .get("/int/refterminologies/ROX37977120443872964/concepts/ROX37977120443872972")
      .headers(headers_ADMIN))
    .exec(http("ReadATwithBrowser request_21")
      .get("/int/refterminologies/ROX37977120443872964/concepts/ROX37977120443872972/xrefs/deeplinks")
      .headers(headers_ADMIN))
    .exec(http("ReadATwithBrowser request_22")
      .get("/int/refterminologies/ROX37977120443872964")
      .headers(headers_ADMIN))
    .exec(http("ReadATwithBrowser request_23")
      .get("/int/refterminologies/ROX37977120443872964/concepts/ROX37977120443872972/labels")
      .headers(headers_ADMIN))
    .exec(http("ReadATwithBrowser request_24")
      .get("/int/appterminologies/ROX37977120443872986/concepts/ROX37977120443872972/classpaths")
      .headers(headers_ADMIN))
  /////////////////////////////////

  val scnUAT = scenario("ReadATwithBrowserUAT")//.feed(AppTermID)

    .group("ReadATwBrowser") {
//      .group("ReadATwBrowser1") {

      exec(http("get term")
        .get("/int/applications/ROX37663488443822742/terminologies")
        .headers(headers_ADMIN))
        .pause(1 seconds, 2 seconds)

        .exec(http("get appterm")
          .get("/int/appterminologies/ROX37672992443823522")
          .headers(headers_ADMIN))
        .pause(1 seconds, 2 seconds)
        .exec(http("get topconcepts")
          .get("/int/appterminologies/ROX37672992443823522/concepts?topConcepts=true&fields=id,pref_label,status,has_children&page=1&per_page=10000")
          .headers(headers_ADMIN))
        .pause(1 seconds, 2 seconds)
   /* }

    .group("ReadATwBrowser2") {
*/
    exec(http("get concept")
      .get("/int/refterminologies/ROX32425734286089737/concepts/ROX38060064443946524")
      .headers(headers_ADMIN)
      .resources(http("search concept")
        .get("/int/search/uri/ROX38060064443946524")
        .headers(headers_ADMIN),
        http("get concepts")
          .get("/int/refterminologies/ROX32425734286089737/concepts/ROX38060064443946524")
          .headers(headers_ADMIN),
        http("get labels")
          .get("/int/refterminologies/ROX32425734286089737/concepts/ROX38060064443946524/labels")
          .headers(headers_ADMIN),
        http("get refterm")
          .get("/int/refterminologies/ROX32425734286089737")
          .headers(headers_ADMIN),
        http("get xrefs")
          .get("/int/refterminologies/ROX32425734286089737/concepts/ROX38060064443946524/xrefs")
          .headers(headers_ADMIN),
        http("get applicablelabels")
          .get("/int/appterminologies/ROX37672992443823522/concepts/ROX38060064443946524/applicableLabels")
          .headers(headers_ADMIN),
        http("get metadata")
          .get("/int/refterminologies/ROX32425734286089737/metadata")
          .headers(headers_ADMIN)))
      .pause(1 seconds, 2 seconds)

 /* }

    .group("ReadATwBrowser2") {
*/
    exec(http("get concept")
      .get("/int/refterminologies/ROX32425734286089737/concepts/ROX37474272443798503")
      .headers(headers_ADMIN)
      .resources(http("searchuri")
        .get("/int/search/uri/ROX37474272443798503")
        .headers(headers_ADMIN),
        http("getrefterm")
          .get("/int/refterminologies/ROX32425734286089737")
          .headers(headers_ADMIN),
        http("get xrefs")
          .get("/int/refterminologies/ROX32425734286089737/concepts/ROX37474272443798503/xrefs")
          .headers(headers_ADMIN),
        http("get concept")
          .get("/int/refterminologies/ROX32425734286089737/concepts/ROX37474272443798503")
          .headers(headers_ADMIN),
        http("get labels")
          .get("/int/refterminologies/ROX32425734286089737/concepts/ROX37474272443798503/labels")
          .headers(headers_ADMIN),
        http("get applicablelabels")
          .get("/int/appterminologies/ROX37672992443823522/concepts/ROX37474272443798503/applicableLabels")
          .headers(headers_ADMIN)))
      .pause(1 seconds, 2 seconds)
  /*}

    .group("ReadATwBrowser3") {
*/
    exec(http("search applications")
      .post("/int/search/applications")
      .headers(headers_ADMIN)
      .body(StringBody(
        //"app_id": "${terminology_id}",
        //
        """{
          |"app_id": "ROX37663488443822742",
          |"page": 1,
          |"per_page": 100,
          |"text": "sepia",
          |"fuzzy":false,
          |"scope":"applications",
          |"concepts_only":true
					|}""".stripMargin)).asJson
    )

      .pause(1)
      .exec(http("get classpaths")
        .get("/int/refterminologies/ROX32425734286089737/concepts/ROX37928736443868953/classpaths")
        .headers(headers_ADMIN)
        .resources(http("get concept")
          .get("/int/refterminologies/ROX32425734286089737/concepts/ROX37928736443868953")
          .headers(headers_ADMIN),
          http("searchuri")
            .get("/int/search/uri/ROX37928736443868953")
            .headers(headers_ADMIN),
          http("get labels")
            .get("/int/refterminologies/ROX32425734286089737/concepts/ROX37928736443868953/labels")
            .headers(headers_ADMIN),
          http("get concept")
            .get("/int/refterminologies/ROX32425734286089737/concepts/ROX37928736443868953")
            .headers(headers_ADMIN),
          http("get xrefs")
            .get("/int/refterminologies/ROX32425734286089737/concepts/ROX37928736443868953/xrefs")
            .headers(headers_ADMIN),
          http("get refterm")
            .get("/int/refterminologies/ROX32425734286089737")
            .headers(headers_ADMIN),
          http("get apllicablelabels")
            .get("/int/appterminologies/ROX37672992443823522/concepts/ROX37928736443868953/applicableLabels")
            .headers(headers_ADMIN),
          http("get classpaths")
            .get("/int/refterminologies/ROX32425734286089737/concepts/ROX37928736443868953/classpaths")
            .headers(headers_ADMIN)))
  }
  ////////////////////////////////
}