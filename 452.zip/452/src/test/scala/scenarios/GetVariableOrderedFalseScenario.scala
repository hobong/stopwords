/*
Used for testing endpoint Get all variables for given domain id
for task RTSIVD-79 with the following domain ids:
GetVariableOrderedFalseScenario - ROX37897632443853426 take variables when "ordered": false
 */
package scenarios

import requests.variables.GetVariablesListUnderDomainRequest
import io.gatling.core.Predef._
import scala.concurrent.duration._

object GetVariableOrderedFalseScenario {
  val getVariableOrderedFalse = scenario("Get Variable ")
    .repeat(1, "repeat_counter") {
      pause(5 seconds).exec(GetVariablesListUnderDomainRequest.getVariablesListUnderDomain) }
}