package scenarios

import requests.external._
import io.gatling.core.Predef._
import scala.concurrent.duration._

object ExternalStressTestScenario {
  val externalStressTestScenario = scenario("External endpoints stress test")
    .exec(ReadApplicationTerminologiesRequest.readApplicationTerminologiesRequest)
    .pause(1 seconds)
    .exec(ReadAppTerminologyConceptsListParamsRequest.readAppTerminologyConceptsListRequest)
    .pause(1 seconds)
    .exec(ReadAppTerminologyConceptsListRequest.readAppTerminologyConceptsListRequest)
    .pause(1 seconds)
    .exec(ReadAppTerminologyDetailsRequest.readAppTerminologyDetailsCuratedRequest)
    .pause(1 seconds)
    .exec(ReadAppTerminologyPublishedConceptsParamsRequest.readAppTerminologyPublishedConceptsParamsRequest)
    .pause(1 seconds)
    .exec(ReadAppTerminologyPublishedConceptsRequest.readAppTerminologyConceptsListRequest)
    .pause(1 seconds)
    .exec(ReadAppTerminologyXRefsRequest.readAppTerminologyXRefsRequest)
    .pause(1 seconds)
    .exec(ReadDomainDetailsRequest.readDomainDetailsRequest)
    .pause(1 seconds)
    .exec(ReadDomainsRequest.readDomainsRequest)
    .pause(1 seconds)
    .repeat(1, "repeat_counter") { pause(2 seconds).exec(ReadDomainVariablesRequest.readDomainVariablesRequest) }
    .pause(1 seconds)
    .exec(ReadHealthcheckRequest.readHealthcheckRequest)
    .pause(1 seconds)
    .exec(ReadVariableDetailsRequest.readVariableDetailsRequest)
}