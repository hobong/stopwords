/*
Used for testing endpoint Get all variables for given domain id
for task RTSIVD-79 with the following domain ids:
CreateVariableOrder - ROX37914912443862547
getVariablesNonOrderedRequest - ROX37914912443863784
getVariablesOrderedRequest - ROX37914912443863769
application - ROX37914912443862484
 */
package scenarios

import requests.variables.GetVariablesListRequest
import io.gatling.core.Predef._
import scala.concurrent.duration._

object GetVariablesListScenario {
  val getVariableListNotOrdered = scenario("Get Variable list when domain not ordered")
    .repeat(1, "repeat_counter") {
      pause(5 seconds).exec(GetVariablesListRequest.getVariablesNonOrderedRequest) }

  val getVariableListOrdered = scenario("Get Variable list when domain ordered")
    .repeat(1, "repeat_conuter") {
      pause(5 seconds).exec(GetVariablesListRequest.getVariablesOrderedRequest)
    }
}