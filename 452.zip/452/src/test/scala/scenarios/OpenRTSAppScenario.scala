package scenarios

import requests.ReadUserDetailsRequest
import io.gatling.core.Predef._
import requests.application.ReadAllApplicationsRequest

object OpenRTSAppScenario {
  val openRTSAppScenario = scenario("Open RTS Application")
    .exec(ReadUserDetailsRequest.getUserDetails)
    .pause(5)
    .exec(ReadAllApplicationsRequest.getApplications)
    .pause(5)
}
