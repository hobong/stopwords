package scenarios

import requests.refterminology.{MoveConceptDestinationIdRequest, MoveConceptRequest}
import io.gatling.core.Predef._
import scala.concurrent.duration._

object MoveConceptScenario {
  val moveConceptScenario = scenario ("Move concepts with multiple labels between MT")
    .exec(MoveConceptDestinationIdRequest.moveConcept)
    .pause(5 seconds)
}