package scenarios

import io.gatling.core.Predef._
import io.gatling.http.Predef._
import config.Config._

object Reading1KpageATScenario {


  val API_VER = "v2"

  val TermID = csv(s"data\\ReadingPagesAT\\${env}pages1K.csv").random

  val scn = scenario("Read1KPages").feed(TermID)

    .group("Read1KPages") {
      exec(http("ReadTerm")
        .get("/v2/appterminologies/${tid}")
        .headers(headers_ADMIN))
        .pause(1, 2)

       .exec(http("page1")
          .get("/v2/appterminologies/${tid}/concepts?topConcepts=true&fields=id,pref_label,status,has_children&page=1&per_page=100")
          .headers(headers_ADMIN)
        .resources(http("page2")
            .get("/v2/appterminologies/${tid}/concepts?topConcepts=true&fields=id,pref_label,status,has_children&page=2&per_page=100")
            .headers(headers_ADMIN),
            http("page3")
              .get("/v2/appterminologies/${tid}/concepts?topConcepts=true&fields=id,pref_label,status,has_children&page=3&per_page=100")
              .headers(headers_ADMIN)
          )
       )

    }

}

