package scenarios

import io.gatling.core.Predef.scenario
import requests.variables.MappingVariableRequest

object MappingVariableScenario {
  val mappingVariableScenario = scenario("Mapping terms to variables in a Domain")
    .exec(MappingVariableRequest.mappVariable)
}