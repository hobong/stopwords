package scenarios


import io.gatling.core.Predef.{scenario, _}
import io.gatling.core.body.StringBody
import io.gatling.jdbc.Predef._
import io.gatling.http.Predef._
import config.Config._
import scala.concurrent.duration._

/*
5 concurrent writing users doing
* creation of Master Terminology Concepts
* Adding 2 labels to the new concept
* Adding one Xref to the new concept
*/

object ComplexWriteMTScenario {

// DEV
//  val CONCEPT_ID = "ROX37984032443881639"
//  val TERMINOLOGY_ID = "ROX37984032443881638"

// UAT
  val CONCEPT_ID = "ROX38043648443946477"
  val TERMINOLOGY_ID = "ROX38042784443946469"


  val scn = scenario("WriteMT")

    .group("WriteMT") {
      exec(http("post")
        .post("/int/refterminologies/" + TERMINOLOGY_ID + "/concepts")
        .headers(headers_ADMIN)
        .body(RawFileBody("bodies/writeMT/0012_request.json"))
        .resources(http("get topconcepts")
          .get("/int/refterminologies/" + TERMINOLOGY_ID + "/topconcepts")
          .headers(headers_ADMIN),
          http("Label  get concept")
            .get("/int/refterminologies/" + TERMINOLOGY_ID + "/concepts/" + CONCEPT_ID)
            .headers(headers_ADMIN),
          http("Label  get labels")
            .get("/int/refterminologies/" + TERMINOLOGY_ID + "/concepts/" + CONCEPT_ID + "/labels")
            .headers(headers_ADMIN),
          http("Label  get metadata")
            .get("/int/refterminologies/" + TERMINOLOGY_ID + "/metadata")
            .headers(headers_ADMIN)
        )
      )
      //pause(1, 2)
   /* }
    .group("WriteMT2") {*/

      exec(http("post2")
        .post("/int/refterminologies/" + TERMINOLOGY_ID + "/concepts")
        .headers(headers_ADMIN)
        .body(RawFileBody("bodies/writeMT/0028_request.json"))
        .resources(
          http(" get labels")
            .get("/int/refterminologies/" + TERMINOLOGY_ID + "/concepts/" + CONCEPT_ID + "/labels")

            .headers(headers_ADMIN)
        )
      )

      //pause(1, 2)
    }


}