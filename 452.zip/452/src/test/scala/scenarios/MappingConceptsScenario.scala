package scenarios

import io.gatling.core.Predef.scenario
import requests.appterminology.MappingConceptsRequest

object MappingConceptsScenario {
  val mappingConceptsScenario = scenario("Mapping terms to Concepts")
    .exec(MappingConceptsRequest.mappConcepts)

}
