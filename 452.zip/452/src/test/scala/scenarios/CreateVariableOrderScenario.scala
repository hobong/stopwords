/*
test under domain with 150 variables under domain int/applications/ROX37914912443862484/domains/ROX37914912443862547
 */
package scenarios

import requests.variables.CreateVariableOrderRequest
import io.gatling.core.Predef.scenario

object CreateVariableOrderScenario {
  val createVariableOrderScenario = scenario("Create Variable order")
    .exec(CreateVariableOrderRequest.createVariableOrder)}