package config

import com.typesafe.scalalogging.Logger


object Config {

  def getProperty(propertyName: String, defaultValue: String): String = {
    Option(System.getenv(propertyName))
      .orElse(Option(System.getProperty(propertyName)))
      .getOrElse(defaultValue)
  }

  val appDevURL = "https://ontology-services-dev.roche.com/rts2-api"
  val appUatURL = "https://ontology-services-uat.roche.com/rts2-api"
  val appPrdURL = "https://ontology-services.roche.com/rts2-api"

  var appURL: String = "Env=not-set"
  def env: String = getProperty("Env", "DEV")

  env match {
    case "DEV" =>      appURL = appDevURL
      Logger("CONFIG").info(s" ENV set to ${appURL}")
    case "UAT" =>      appURL = appUatURL
      Logger("CONFIG").info(s" ENV set to ${appURL}")
    case "PRD" =>      appURL = appPrdURL
      Logger("CONFIG").info(s" ENV set to ${appURL}")
    case _ => Logger("CONFIG").info("Env=not-set => using DEV")
  }


  val headers_USER = Map(
    "Content-Type" -> "application/json;charset=UTF-8",
    // "Origin" -> appURL,
    "Sec-Fetch-Dest" -> "empty",
    "Sec-Fetch-Mode" -> "cors",
    "Sec-Fetch-Site" -> "same-origin",
    "Authorization" -> "Basic cnRzMnRzdDM6ZEQyM3Y2NVpoZlJ0OQ==") //USER

  val headers_ADMIN = Map(
    "Content-Type" -> "application/json;charset=UTF-8",
    //  "Origin" -> appURL,
    "Sec-Fetch-Dest" -> "empty",
    "Sec-Fetch-Mode" -> "cors",
    "Sec-Fetch-Site" -> "same-origin",
    "Authorization" -> "Basic cnRzMnRzdDE6ZkYzNHg3NllnbVJROA==") //ADMIN      psw   fF34x76YgmRQ8

  val headers_CURATOR = Map(
    "Content-Type" -> "application/json;charset=UTF-8",
    //  "Origin" -> appURL,
    "Sec-Fetch-Dest" -> "empty",
    "Sec-Fetch-Mode" -> "cors",
    "Sec-Fetch-Site" -> "same-origin",
    "Authorization" -> "Basic cnRzMnRzdDI6ZEQyM3Y2NVpoZlJ0OQ==") //CURATOR

  val headers_APP = Map(
    "Content-Type" -> "application/json;charset=UTF-8",
    // "Origin" -> appURL,
    "Sec-Fetch-Dest" -> "empty",
    "Sec-Fetch-Mode" -> "cors",
    "Sec-Fetch-Site" -> "same-origin",
    "Authorization" -> "Basic UlRTMkFQUFQ6clQyMkJpbmIwNVRz==") //APP

  //Params for the whole simulation:
  def simulationName: String = getProperty("gatling.simulationClass", "SIMULATION CLASS NAME NOT SET")

  def simulationMaxTime: Int = getProperty("simulationMaxTime", "1200").toInt

  def expectedMeanRespTime: Int = getProperty("expectedMeanRespTime", "1500").toInt

  def expectedMaxfailedRequestsPercent: Int = getProperty("expectedMaxfailedRequestsPercent", "3").toInt



  //Old way of configuring - not used here
  val sentHeaders = Map(
    "Content-Type" -> "application/json",
    "Authorization" -> "Basic cnRzMnRzdDE6ZEQyM3Y2NVpoZlJ0OQ==")

  val users = Integer.getInteger("users", 10).toInt
  val rampUp = Integer.getInteger("rampup", 1).toInt
  val throughput = Integer.getInteger("throughput", 100).toInt
  val aid = "ROX37650528443820956"
  val did = "ROX37839744443834587"

}
