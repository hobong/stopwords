/* Simulation for testing task RTSIV-49 */

package simulations

import scenarios.GetAllApplicationsScenario
import config.Config._
import io.gatling.core.Predef._
import scala.concurrent.duration._

class GetAllApplicationsSimulation extends Simulation {
  private val getAllApplicationsExec = GetAllApplicationsScenario.getApplicationsUser
    .inject(rampUsers(users) during (10 seconds))
      //.inject(atOnceUsers(users))

  setUp(getAllApplicationsExec)
}
