/* Simulation used to retest improvement RTSIVD-30 */
package simulations

import scenarios.PostRefTerminologyContentScenario
import config.Config._
import io.gatling.core.Predef._

class PostRefTerminologyContentSimulation extends Simulation {
  private val postRefTerminologyContentExec = PostRefTerminologyContentScenario.postRefTerminologyContentScenario
    .inject(atOnceUsers(users))

  setUp(postRefTerminologyContentExec)
}
