package simulations

import config.Config._
import scenarios.SearchScenario
import io.gatling.core.Predef._

class SearchSimulation extends Simulation {
  private val searchExec = SearchScenario.searchScenario
    .inject(atOnceUsers(users))

  setUp(searchExec)
}