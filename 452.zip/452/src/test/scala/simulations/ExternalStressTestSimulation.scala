package simulations

import config.Config._
import scenarios.ExternalStressTestScenario
import io.gatling.core.Predef._
import scala.concurrent.duration._

class ExternalStressTestSimulation extends Simulation {
  private val externalStressTestExec = ExternalStressTestScenario.externalStressTestScenario
      .inject {
        rampUsers(2) during (10 seconds)
      }

  setUp(externalStressTestExec)
}