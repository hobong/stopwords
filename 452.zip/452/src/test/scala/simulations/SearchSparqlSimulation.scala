package simulations

import config.Config._
import scenarios.SearchSparqlScenario
import io.gatling.core.Predef._

class SearchSparqlSimulation extends  Simulation {
  private val searchSparqlExec = SearchSparqlScenario.searchSparqlScenario
    .inject(atOnceUsers(users))

  setUp(searchSparqlExec)
}