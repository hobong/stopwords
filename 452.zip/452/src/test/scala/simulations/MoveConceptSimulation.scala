package simulations

import config.Config.users
import scenarios.MoveConceptScenario
import io.gatling.core.Predef._
import scala.concurrent.duration._

class MoveConceptSimulation extends Simulation {
  private val moveConceptExec = MoveConceptScenario.moveConceptScenario
    .inject(rampUsers(users) during (60 second))

  setUp(moveConceptExec)
}