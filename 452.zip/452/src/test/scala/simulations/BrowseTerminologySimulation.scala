package simulations

import config.Config._
import scenarios.{OpenRTSAppScenario, OpenMasterTermScenario, OpenConceptEntityScenario, OpenTabScenario}
import io.gatling.core.Predef._
import scala.concurrent.duration._

class BrowseTerminologySimulation extends Simulation {
  private val openRTSExec = OpenRTSAppScenario.openRTSAppScenario
  private val openMasterExec = OpenMasterTermScenario.openMasterTermScenario
  private val openConceptEntityExec = OpenConceptEntityScenario.openConceptEntityScenario
  private val openTabExec = OpenTabScenario.openTabScenario


  setUp(
    openRTSExec.inject {
      //rampUsers(users) over 40
      //splitUsers(users) into(rampUsers(2) over(10 seconds)) separatedBy(2 seconds)
      rampUsers(users) during (10 seconds)
    },
    openMasterExec.inject {
      rampUsers(2) during (10 seconds)
    },
    openConceptEntityExec.inject {
      rampUsers(2) during (10 seconds)
    },
    openTabExec.inject {
      rampUsers(2) during (10 seconds)
    }
  )
}