package simulations

import config.Config._
import scenarios.GetVariablesListScenario
import scenarios.CreateVariableOrderScenario
import io.gatling.core.Predef._
import scala.concurrent.duration._

class VariableOrderSimulation extends Simulation {

  // for testing not ordered domain, test with GetVariablesListScenario.getVariableListNotOrdered
  // for testing ordered domain, test with GetVariablesListScenario.getVariableListOrdered
  // for testing creation of variable_order, test with CreateVariableOrderScenario

  private val variableOrderSimulation = GetVariablesListScenario.getVariableListOrdered
    .inject {
      atOnceUsers(1)
    }

  setUp(variableOrderSimulation)
}