package simulations

import config.Config._
import scenarios.MappingConceptsScenario
import io.gatling.core.Predef._

class MappingConceptsSimulation extends Simulation {
  private val mappingConceptsExec = MappingConceptsScenario.mappingConceptsScenario
    .inject(atOnceUsers(users))

  setUp(mappingConceptsExec)
}
