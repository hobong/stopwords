package simulations

import config.Config._
import scenarios.AddConceptsListScenario
import io.gatling.core.Predef._

class AddConceptsListSimulation extends Simulation {
  private val addConceptsListExec = AddConceptsListScenario.addConceptsListScenario.inject(atOnceUsers(users))

  setUp(addConceptsListExec)
}
