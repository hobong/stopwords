package simulations

import config.Config._
import scenarios.CreateVariableScenario
import io.gatling.core.Predef._
import scala.concurrent.duration._

class CreateVariableSimulation extends Simulation {
  private val createVariableExec = CreateVariableScenario.createVariableScenario
    .inject {
      rampUsers(users) during 40
      //splitUsers(users) into(rampUsers(2) over(10 seconds)) separatedBy(2 seconds)
      //constantConcurrentUsers(users) during (10 seconds)
    }

  setUp(createVariableExec)
}