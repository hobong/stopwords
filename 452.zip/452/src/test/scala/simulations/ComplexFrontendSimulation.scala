package simulations

import com.typesafe.scalalogging.Logger
import config.Config._
import io.gatling.core.Predef._
import io.gatling.http.Predef._
import io.gatling.http.protocol.HttpProtocolBuilder
import org.apache.http.client.methods.{CloseableHttpResponse, HttpDelete, HttpPut}
import org.apache.http.impl.client.{HttpClientBuilder, HttpClients}
import org.apache.http.util.EntityUtils

import scala.concurrent.duration._
import scenarios.{ComplexWriteMTScenario, ReadATwithBrowserScenario, Reading10KpagePublishedATScenario, Reading1KpageATScenario}


class ComplexFrontendSimulation extends Simulation {


  // Params for scenarios
  //
  def ComplexWriteMT_ramp = getProperty("ComplexWriteMT_ramp", "960").toInt

  def ComplexWriteMT_users = getProperty("ComplexWriteMT_users", "5").toInt

  def ComplexWriteMT_usersFrom = getProperty("ComplexWriteMT_usersFrom", "1").toInt

  def ComplexWriteMT_usersTo = getProperty("ComplexWriteMT_usersTo", "5").toInt

  def ComplexWriteMT_idleTime = getProperty("ComplexWriteMT_idleTime", "0").toInt

  //
  def ReadATwithBrowser_ramp = getProperty("ReadATwithBrowser_ramp", "960").toInt

  def ReadATwithBrowser_users = getProperty("ReadATwithBrowser_users", "20").toInt

  def ReadATwithBrowser_usersFrom = getProperty("ReadATwithBrowser_usersFrom", "1").toInt

  def ReadATwithBrowser_usersTo = getProperty("ReadATwithBrowser_usersTo", "20").toInt

  def ReadATwithBrowser_idleTime = getProperty("ReadATwithBrowser_idleTime", "0").toInt


  //
  def Reading1KpageAT_ramp = getProperty("Reading1KpageAT_ramp", "960").toInt

  def Reading1KpageAT_users = getProperty("Reading1KpageAT_users", "3").toInt

  def Reading1KpageAT_usersFrom = getProperty("Reading1KpageAT_usersFrom", "1").toInt

  def Reading1KpageAT_usersTo = getProperty("Reading1KpageAT_usersTo", "3").toInt

  def Reading1KpageAT_idleTime = getProperty("Reading1KpageAT_idleTime", "0").toInt

  //
  def Reading10KpageAT_ramp = getProperty("Reading10KpageAT_ramp", "960").toInt

  def Reading10KpageAT_users = getProperty("Reading10KpageAT_users", "3").toInt

  def Reading10KpageAT_usersFrom = getProperty("Reading10KpageAT_usersFrom", "1").toInt

  def Reading10KpageAT_usersTo = getProperty("Reading10KpageAT_usersTo", "3").toInt

  def Reading10KpageAT_idleTime = getProperty("Reading10KpageAT_idleTime", "0").toInt


   def scenario_open = getProperty("scenario_open", "true").toBoolean

/*
  private val ComplexWriteMTExec = ComplexWriteMTScenario.scn
    .inject {
     nothingFor(ComplexWriteMT_idleTime)
    //  rampConcurrentUsers(ComplexWriteMT_usersFrom) to (ComplexWriteMT_usersTo) during (ComplexWriteMT_ramp seconds)
      constantUsersPerSec(ComplexWriteMT_usersTo) during (ComplexWriteMT_ramp seconds) randomized
    }

  private val ReadATwithBrowserExec = ReadATwithBrowserScenario.scnUAT
    .inject {
      nothingFor(ReadATwithBrowser_idleTime)
    //  rampConcurrentUsers(ReadATwithBrowser_usersFrom) to (ReadATwithBrowser_usersTo) during (ReadATwithBrowser_ramp seconds)
      constantUsersPerSec(ReadATwithBrowser_usersTo) during (ReadATwithBrowser_ramp seconds) randomized
    }

   private val Reading1KpageATExec = Reading1KpageATScenario.scn
    .inject {
    //  nothingFor(Reading1KpageAT_idleTime)
      rampConcurrentUsers(Reading10KpageAT_usersFrom) to (Reading10KpageAT_usersTo) during (Reading1KpageAT_ramp seconds)
    }

  private val Reading10KpagePublishedATExec = Reading10KpagePublishedATScenario.scn
    .inject {
      nothingFor(Reading10KpageAT_idleTime)
      rampConcurrentUsers(Reading10KpageAT_usersFrom) to (Reading10KpageAT_usersTo) during (Reading10KpageAT_ramp seconds)
    }
 */
///////////
///Open workload
  private val ComplexWriteMTExec = ComplexWriteMTScenario.scn
    .inject {
      nothingFor(ComplexWriteMT_idleTime)
        atOnceUsers(ComplexWriteMT_usersTo)
    }

  private val ReadATwithBrowserExec = ReadATwithBrowserScenario.scnUAT
    .inject {
      nothingFor(ReadATwithBrowser_idleTime)
      atOnceUsers(ReadATwithBrowser_usersTo)
    }

  private val Reading1KpageATExec = Reading1KpageATScenario.scn
    .inject {
      nothingFor(Reading1KpageAT_idleTime)
      atOnceUsers(Reading1KpageAT_usersTo)
    }

  private val Reading10KpagePublishedATExec = Reading10KpagePublishedATScenario.scn
    .inject {
      nothingFor(Reading10KpageAT_idleTime)
      atOnceUsers(Reading10KpageAT_usersTo)
    }
//////////////

  before {
    Logger("CONFIG").info(
      s"""
*********************************************************
Running ${simulationName}  with parameters:
  Total test duration: ${simulationMaxTime} seconds
Assertions: 
  expectedMeanRespTime: $expectedMeanRespTime
  failedRequests less than : $expectedMaxfailedRequestsPercent
  ***************************************

  ComplexWriteMT_ramp:  $ComplexWriteMT_ramp
  ComplexWriteMT_users:  $ComplexWriteMT_users
  ComplexWriteMT_usersFrom:  $ComplexWriteMT_usersFrom
  ComplexWriteMT_usersTo:  $ComplexWriteMT_usersTo
  ComplexWriteMT_idleTime:  $ComplexWriteMT_idleTime

  ReadATwithBrowser_ramp: $ReadATwithBrowser_ramp
  ReadATwithBrowser_users: $ReadATwithBrowser_users
  ReadATwithBrowser_usersFrom:  $ReadATwithBrowser_usersFrom
  ReadATwithBrowser_usersTo:  $ReadATwithBrowser_usersTo
  ReadATwithBrowser_idleTime:  $ReadATwithBrowser_idleTime

  Reading1KpageAT_ramp:  $Reading1KpageAT_ramp
  Reading1KpageAT_users:  $Reading1KpageAT_users
  Reading1KpageAT_usersFrom:  $Reading1KpageAT_usersFrom
  Reading1KpageAT_usersTo:  $Reading1KpageAT_usersTo
  Reading1KpageAT_idleTime:  $Reading1KpageAT_idleTime

  Reading10KpageAT_ramp:  $Reading10KpageAT_ramp
  Reading10KpageAT_users:  $Reading10KpageAT_users
  Reading10KpageAT_usersFrom:  $Reading10KpageAT_usersFrom
  Reading10KpageAT_usersTo:  $Reading10KpageAT_usersTo
  Reading10KpageAT_idleTime:  $Reading10KpageAT_idleTime
**************************************************************
""")

  }

  val httpConf: HttpProtocolBuilder = http
    .baseUrl(appURL)
    .acceptHeader("application/json, text/plain, */*")
    .acceptEncodingHeader("gzip, deflate")
    .acceptLanguageHeader("en-US,en;q=0.9")
    .userAgentHeader("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36")
  //.proxy(Proxy("localhost", 8888).httpsPort(8888))   <= to proxy when debugging script>


  setUp(
      ComplexWriteMTExec,
      ReadATwithBrowserExec,
      Reading1KpageATExec,
      Reading10KpagePublishedATExec
  )
    .protocols(httpConf)
    .maxDuration(simulationMaxTime.seconds)
    .assertions(
      global.responseTime.mean.lt(expectedMeanRespTime),
      forAll.failedRequests.percent.lt(expectedMaxfailedRequestsPercent)
    )

  after {
    // cleanup
    Logger("CONFIG").info(
      """ Cleanup called
        |""".stripMargin)


    /*    Example use HttpClient in "before" clause
    */
  /*  val httpClient = HttpClientBuilder.create.build


    val CONCEPT_ID = "ROX37984032443881639"
    //  val TERMINOLOGY_ID = "ROX37984032443881638"
    val TERMINOLOGY_ID = "ROX38072160444118780"


    //  val json = """{"groupId":"group_91198855-afbc-4726-856f-31326173a90f"}"""
    val url = s"https://ontology-services-dev.roche.com/int/refterminologies/${{TERMINOLOGY_ID}}"
    val client = HttpClients.createMinimal()
    //  val post:HttpPost = new HttpPost(url)
    val del: HttpDelete = new HttpDelete(url)

    del.addHeader("Content-Type", "application/json;charset=UTF-8")
    del.addHeader("Sec-Fetch-Mode", "cors")
    del.addHeader("Sec-Fetch-Site", "same-origin")
    del.addHeader("Authorization", "Basic cnRzMnRzdDE6ZkYzNHg3NllnbVJROA==")


    val response: CloseableHttpResponse = client.execute(del)
    val entity = response.getEntity
    val str = EntityUtils.toString(entity, "UTF-8")
    Logger("INFO").info("----del resp------------")
    Logger("INFO").info(str)
*/



  }

}
