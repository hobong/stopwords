package simulations

import config.Config._
import scenarios.MappingVariableScenario
import io.gatling.core.Predef._

class MappingVariableSimulation extends Simulation{
  private val mappingVariableExec = MappingVariableScenario.mappingVariableScenario
    .inject(atOnceUsers(users))

  setUp(mappingVariableExec)
}
