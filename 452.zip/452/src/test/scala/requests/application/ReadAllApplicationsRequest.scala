package requests.application

import config.Config._
import io.gatling.core.Predef._
import io.gatling.http.Predef._

object ReadAllApplicationsRequest {
  val getApplications = exec(http("Get list of defined Applications")
    .get(appDevURL + "/int/applications")
    .headers(sentHeaders))
}