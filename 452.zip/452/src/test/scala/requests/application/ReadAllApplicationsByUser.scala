/* Request used to test RTSIVD-49
* with ROLE_GLORTS2_BROWSE account rts2tst4*/

package requests.application

import config.Config._
import io.gatling.core.Predef._
import io.gatling.http.Predef._

object ReadAllApplicationsByUser {
  val getApplicationsUser = exec(http("Get list of user Applications")
    .get(appDevURL + "/int/applications")
    .headers(Map(
      "Content-Type" -> "application/json",
      "Referer" -> "https://ontology-services-dev.roche.com/rts2-ui/index.html",
      "Authorization" -> "Basic cnRzMnRzdDQ6eVNZaWlZMXpOM3B0")))
    .exec(flushHttpCache)
}