package requests.appterminology

import config.Config._
import io.gatling.core.Predef._
import io.gatling.http.Predef._

object MappingConceptsRequest {
  val appTerm = csv("data\\DevAppTerm.csv").circular

  val mappConcepts = feed(appTerm).exec(http("Mapping terms to Concepts")
    .post(appDevURL + "/int/appterminologies/${terminology_id}/concepts/mappings")
    .headers(sentHeaders)
    .body(RawFileBody("bodies\\mappConceptALT.json")).asJson)
}