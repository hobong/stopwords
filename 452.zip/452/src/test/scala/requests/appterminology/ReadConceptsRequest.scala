package requests.appterminology

import config.Config._
import io.gatling.core.Predef._
import io.gatling.http.Predef._

object ReadConceptsRequest {

  val readConcepts = exec(http("Read app terminology concepts")
    .get(appDevURL + "/int/appterminologies/ROX37766304443831370/concepts?topConcepts=true&fields=id,pref_label,status,status_id,has_children")
    .headers(sentHeaders)
    .check(status.is(200)))
}
