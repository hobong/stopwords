package requests.appterminology

import config.Config._
import io.gatling.core.Predef._
import io.gatling.http.Predef._

object TransferConceptRequest {

  val ConceptID = csv("data\\CellLineId.csv").circular

  val transferConcept = feed(ConceptID)
    .exec(http("Transfer concepts to app terminology")
      .post(appDevURL + "/int/appterminologies/ROX37766304443831370/concepts/transfer")
      .headers(sentHeaders)
      .body(RawFileBody("bodies\\\\addConceptsListBody.json")).asJson
      .check(status.is(200)))
}
