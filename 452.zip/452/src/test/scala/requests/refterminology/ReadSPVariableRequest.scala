package requests.refterminology

import config.Config._
import io.gatling.http.Predef._
import io.gatling.core.Predef._

object ReadSPVariableRequest {
  val readSPVariableRequest = exec(http("Read SP Variable")
    .get("/int/refterminologies/ROX37346400443777268/topconcepts")
    .headers(sentHeaders)
    .check(status.is(200)))
}
