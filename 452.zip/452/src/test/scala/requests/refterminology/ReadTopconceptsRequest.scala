package requests.refterminology

import config.Config._
import io.gatling.core.Predef._
import io.gatling.http.Predef._

object ReadTopconceptsRequest {
  val TermId = csv("data\\UatTerm.csv").circular
  val readTopconcepts = feed(TermId)
    .exec(http("Read Master Terminology topconcepts")
      .get(appDevURL + "/int/refterminologies/${tid}/topconcepts")
      .headers(sentHeaders))
}