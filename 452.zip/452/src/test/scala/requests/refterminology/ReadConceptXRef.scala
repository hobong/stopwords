package requests.refterminology

import config.Config._
import io.gatling.core.Predef._
import io.gatling.http.Predef._

object ReadConceptXRef {
  val ConceptId = csv("data\\UatTermConcept.csv").circular

  val readConceptXRef = feed(ConceptId).exec(http("Read Concept XRefs")
    .get(appDevURL + "/int/refterminologies/${TERMINOLOGY_ID}/concepts/${CONCEPT_ID}/xrefs")
    .headers(sentHeaders))
}
