package requests.refterminology

import config.Config._
import io.gatling.core.Predef._
import io.gatling.http.Predef._

object ReadMasterTermRequest {
  val readMasterTerm = exec(http("Read Master Terminologies")
    .get(appDevURL + "/int/refterminologies?type=master")
    .headers(sentHeaders))
}