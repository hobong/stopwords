/*
  destinationId=ROX37679040443821191
  terminology ROX32425774572250970
  endpoint /int/refterminologies/ROX32425774572250970/concepts/${cid}/movetoterminology?destinationTid=ROX37679040443821191
   */

package requests.refterminology

import config.Config._
import io.gatling.core.Predef._
import io.gatling.http.Predef._

object MoveConceptDestinationIdRequest {
  val ConceptLabels = csv("data\\ConceptsWithLabels.csv").circular

  val moveConcept = feed(ConceptLabels)
    .exec(http("Move concept between Master Terminologies")
    .put(appUatURL + "/int/refterminologies/ROX32425774572250970/concepts/ROX1305277804139/movetoterminology?destinationTid=ROX37915776443864270")
    .headers(sentHeaders)
    .body(StringBody("""{"tid":"ROX32425774572250970","cid":"ROX1305277804139","destinationTid":"ROX37915776443864270"}""")).asJson)
}