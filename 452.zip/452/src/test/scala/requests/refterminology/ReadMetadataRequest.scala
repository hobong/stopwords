package requests.refterminology

import config.Config._
import io.gatling.core.Predef._
import io.gatling.http.Predef._

object ReadMetadataRequest {
  val ConceptId = csv("data\\UatTermConcept.csv").circular

  val readMetadata = feed(ConceptId)
    .exec(http("Read metadata")
      .get(appDevURL + "/int/refterminologies/${TERMINOLOGY_ID}/metadata")
      .headers(sentHeaders))
}
