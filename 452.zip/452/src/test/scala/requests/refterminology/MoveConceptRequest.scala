package requests.refterminology

import config.Config._
import io.gatling.http.Predef._
import io.gatling.core.Predef._

object MoveConceptRequest {
  val ConceptLabels = csv("data\\ConceptsWithLabels.csv").circular

  val moveConcept = feed(ConceptLabels)
    .exec(http("Move concept between Master Terminologies")
      .put(appDevURL + "/int/refterminologies/ROX32425774572250970/concepts/ROX1325611815991/movetoterminology")
      .headers(sentHeaders)
      .body(StringBody("""{"target_terminology_id": "ROX37679040443821191","target_broader_id": null}""")).asJson)
}
