package requests.refterminology

import config.Config._
import io.gatling.core.Predef._
import io.gatling.http.Predef._

object ReadAppTermRefsRequest {

  val ConceptId = csv("data\\UatTermConcept.csv").circular

  val readAppTermRefs = feed(ConceptId)
    .exec(http("Read appterm refs")
      .get(appDevURL + "/int/refterminologies/concepts/${CONCEPT_ID}/apptermrefs")
      .headers(sentHeaders))
}
