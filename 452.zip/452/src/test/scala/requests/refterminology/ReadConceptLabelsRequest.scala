package requests.refterminology

import config.Config._
import io.gatling.core.Predef._
import io.gatling.http.Predef._

object ReadConceptLabelsRequest {
  val ConceptId = csv("data\\UatTermConcept.csv").circular

  val readConceptLabels = feed(ConceptId)
    .exec(http("Read concept labels")
      .get(appDevURL + "/int/refterminologies/${TERMINOLOGY_ID}/concepts/${CONCEPT_ID}/labels")
      .headers(sentHeaders))
}
