package requests.refterminology

import config.Config._
import io.gatling.core.Predef._
import io.gatling.http.Predef._

object ReadConceptDetailsRequest {
  val ConceptId = csv("data\\UatTermConcept.csv").circular

  val readConceptDetails = feed(ConceptId)
    .exec(http("Read Concept details")
      .get(appDevURL + "/int/refterminologies/${TERMINOLOGY_ID}/concepts/${CONCEPT_ID}")
      .headers(sentHeaders))
}
