package requests.refterminology

import config.Config._
import io.gatling.core.Predef._
import io.gatling.http.Predef._


object PostRefTerminologyContentRequest {

  val postRefTerminologyContent = exec(http("Bulk insert data into Hosted Terminology")
    .post(appDevURL + "/int/refterminologies/GPP/content")
    .formUpload("file", "bodies//v44.nt0")
    .headers(Map(
      "Content-Type" -> "multipart/form-data",
      "Authorization" -> "BASIC cnRzMnRzdDE6YkQxNGlGNFhZNWZONQ==")))
}