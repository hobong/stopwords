package requests.refterminology

import config.Config._
import io.gatling.core.Predef._
import io.gatling.http.Predef._

object ReadConceptNarrower {

  val ConceptId = csv("data\\UatTermConcept.csv").circular

  val readNarrower = feed(ConceptId)
    .exec(http("Read concept narrower relation")
      .get(appDevURL + "/int/refterminologies/${TERMINOLOGY_ID}/concepts/${CONCEPT_ID}/narrower")
      .headers(sentHeaders))
}