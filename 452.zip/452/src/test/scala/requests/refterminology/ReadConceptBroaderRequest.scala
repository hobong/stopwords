package requests.refterminology

import config.Config._
import io.gatling.core.Predef._
import io.gatling.http.Predef._

object ReadConceptBroaderRequest {

  val ConceptId = csv("data\\UatTermConcept.csv").circular

  val readBroader = feed(ConceptId)
    .exec(http("Read concept broader relation")
      .get(appDevURL + "/int/refterminologies/${TERMINOLOGY_ID}/concepts/${CONCEPT_ID}/broader")
      .headers(sentHeaders))
}
