package requests.search

import config.Config.{appDevURL, sentHeaders}
import io.gatling.core.Predef._
import io.gatling.http.Predef._

object SearchSparqlRequest {

  val concepts = csv("data\\ConceptId.csv").random

  val search_sparql = feed(concepts)
    .exec(http("Post /int/search/sparql")
      .post(appDevURL + "/int/search/sparql")
      .headers(sentHeaders)
      .body(StringBody("""{"text":"${concept_label}","page":1,"per_page":1000,"scope":"all","term_id":"",
                         |"field":["pref_label","alt_label","hid_label","identifier",
                         |"definition","comment"],"fuzzy":false}""".stripMargin)))
}