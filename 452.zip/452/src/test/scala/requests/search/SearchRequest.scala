package requests.search

import config.Config._
import io.gatling.core.Predef._
import io.gatling.http.Predef._

object SearchRequest {
  val concepts = csv("data\\ConceptId.csv").random

  val search = feed(concepts).exec(http("Search")
    .post(appDevURL + "/int/search")
    .headers(sentHeaders)
    .body(StringBody("""{"text":"${concept_label}","page":1,"per_page":1000,"scope":"all","term_id":"",
                       |"field":["pref_label","alt_label","hid_label","identifier",
                       |"definition","comment"],"fuzzy":false}""".stripMargin)))
}
