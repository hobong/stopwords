package requests.search

import config.Config._
import io.gatling.core.Predef._
import io.gatling.http.Predef._

object SearchUriRequest {
  val ConceptId = csv("data\\UatTermConcept.csv").circular

  val searchUri = feed(ConceptId)
    .exec(http("Search Uri")
      .get(appDevURL + "/int/search/uri/${CONCEPT_ID}")
      .headers(sentHeaders))
}
