package requests.external

import config.Config._
import io.gatling.core.Predef._
import io.gatling.http.Predef._

object ReadAppTerminologyPublishedConceptsParamsRequest {
  val AppTerminologyPublishedId = csv("data\\UatAppTerm.csv").circular

  val readAppTerminologyPublishedConceptsParamsRequest = feed(AppTerminologyPublishedId)
    .exec(http("Get list of Application Terminology Published Concepts params")
      .get(appUatURL + "/v2/appterminologies/${terminology_id}/published/concepts?page=1&per_page=1000&fields=pref_label&fields=alt_labels")
      .headers(sentHeaders)
      .check(status.is(200)))
}
