package requests.external

import config.Config._
import io.gatling.http.Predef._
import io.gatling.core.Predef._

object ReadDomainsRequest {
  val ApplicationId = csv("data\\UatApp.csv").circular

  val readDomainsRequest = feed(ApplicationId)
    .exec(http("Read list of domains")
      .get(appUatURL + "/v2/applications/${aid}/domains")
      .headers(sentHeaders)
      .check(status.is(200)))
}
