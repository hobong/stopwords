package requests.external

import config.Config._
import io.gatling.core.Predef._
import io.gatling.http.Predef._

object ReadAppTerminologyXRefsRequest {

  val readAppTerminologyXRefsRequest = exec(http("Read Application Terminology XRefs")
    .get(appUatURL + "/v2/appterminologies/ROX37903680443855550/concepts/xrefs?Xref%20type%20ids=ROX1448447313999&page=1&per_page=1000")
    .headers(sentHeaders)
    .check(status.is(200)))
}
