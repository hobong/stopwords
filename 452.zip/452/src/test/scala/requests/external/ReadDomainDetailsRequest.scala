package requests.external

import config.Config._
import io.gatling.http.Predef._
import io.gatling.core.Predef._

object ReadDomainDetailsRequest {
  val AppDomainId = csv("data\\UatAppDomainVariable.csv").circular

  val readDomainDetailsRequest = feed(AppDomainId)
    .exec(http("Read Domain Details")
      .get(appUatURL + "/v2/applications/${aid}/domains/${did}")
      .headers(sentHeaders)
      .check(status.is(200)))
}