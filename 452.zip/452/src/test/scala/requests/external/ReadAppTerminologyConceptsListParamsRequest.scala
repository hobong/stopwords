package requests.external

import config.Config._
import io.gatling.http.Predef._
import io.gatling.core.Predef._

object ReadAppTerminologyConceptsListParamsRequest {
  val AppTerminologyId = csv("data\\UatAppTerm.csv").circular

  val readAppTerminologyConceptsListRequest = feed(AppTerminologyId)
    .exec(http("Read list of Application Terminology Concepts params")
      .get(appUatURL + "/v2/appterminologies/${terminology_id}/concepts?page=1&per_page=5&fields=pref_label&fields=alt_labels")
      .headers(sentHeaders)
      .check(status.is(200)))
}