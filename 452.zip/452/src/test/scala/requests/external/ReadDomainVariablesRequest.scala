package requests.external

import config.Config._
import io.gatling.http.Predef._
import io.gatling.core.Predef._

object ReadDomainVariablesRequest {
  val AppDomainId = csv("data\\UatAppDomainVariable.csv").circular

  val readDomainVariablesRequest = feed(AppDomainId)
    .exec(http("Read Domain Variables")
      .get(appUatURL + "/v2/applications/ROX37903680443855547/domains/ROX37910592443861627/variables")
      .headers(sentHeaders)
      .check(status.is(200)))
      .exec(flushHttpCache)
}