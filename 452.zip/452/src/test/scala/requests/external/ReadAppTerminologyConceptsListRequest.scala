package requests.external

import config.Config._
import io.gatling.core.Predef._
import io.gatling.http.Predef._

object ReadAppTerminologyConceptsListRequest {
  val AppTerminologyId = csv("data\\UatAppTerm.csv").circular

  val readAppTerminologyConceptsListRequest = feed(AppTerminologyId)
    .exec(http("Read list of Application Terminology Concepts")
      .get(appUatURL + "/v2/appterminologies/${terminology_id}/concepts?page=1&per_page=1000&" +
        "fields=pref_label&fields=pref_label_details&fields=alt_labels&fields=alt_label_details" +
        "&fields=broaders&fields=top_concept&fields=modified&fields=has_children")
      .headers(sentHeaders)
      .check(status.is(200)))
}
