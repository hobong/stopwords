package requests.external

import config.Config._
import io.gatling.http.Predef._
import io.gatling.core.Predef._

object ReadVariableDetailsRequest {
  val AppDomainId = csv("data\\UatAppDomainVariable.csv").circular

  val readVariableDetailsRequest = feed(AppDomainId)
    .exec(http("Read Variable Details")
      .get(appUatURL + "/v2/applications/${aid}/domains/${did}/variables/${vid}")
      .headers(sentHeaders)
      .check(status.is(200)))
}
