package requests.external

import config.Config._
import io.gatling.http.Predef._
import io.gatling.core.Predef._

object ReadHealthcheckRequest {
  val readHealthcheckRequest = exec(http("Read healthcheck")
    .get(appUatURL + "/v2/admin/healthcheck")
    .check(status.is(200)))
}
