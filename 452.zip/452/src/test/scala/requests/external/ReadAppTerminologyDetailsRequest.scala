package requests.external

import config.Config._
import io.gatling.core.Predef._
import io.gatling.http.Predef._

object ReadAppTerminologyDetailsRequest {
  val AppTerminologyId = csv("data\\UatAppTerm.csv").circular

  val readAppTerminologyDetailsCuratedRequest = feed(AppTerminologyId)
    .exec(http("Read Application Terminology Details")
      .get(appUatURL + "/v2/appterminologies/${terminology_id}")
      .headers(sentHeaders)
      .check(status.is(200)))
}
