package requests.external

import config.Config._
import io.gatling.http.Predef._
import io.gatling.core.Predef._

object ReadApplicationTerminologiesRequest {
  val AppTerminologyId = csv("data\\UatApp.csv").circular

  val readApplicationTerminologiesRequest = feed(AppTerminologyId)
    .exec(http("Read all Application Terminologies")
      .get(appUatURL + "/v2/applications/${aid}/terminologies")
      .headers(sentHeaders)
      .check(status.is(200)))
}
