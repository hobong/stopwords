package requests.external

import config.Config._
import io.gatling.core.Predef._
import io.gatling.http.Predef._

object ReadAppTerminologyPublishedConceptsRequest {
  val AppTerminologyPublishedId = csv("data\\UatAppTerm.csv").circular

  val readAppTerminologyConceptsListRequest = feed(AppTerminologyPublishedId)
    .exec(http("Read list of Application Terminology Published Concepts")
      .get(appUatURL + "/v2/appterminologies/${terminology_id}/published/concepts?page=1&per_page=1000&fields=pref_label&fields=pref_label_details&fields=alt_labels&fields=alt_label_details&fields=broaders&fields=top_concept&fields=modified")
      .headers(sentHeaders)
      .check(status.is(200)))
}
