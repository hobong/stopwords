package requests.variables

object OpenApplicationDomainsRequest {

}
