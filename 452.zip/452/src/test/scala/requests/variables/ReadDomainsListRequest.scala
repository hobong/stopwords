package requests.variables

import config.Config._
import io.gatling.core.Predef._
import io.gatling.http.Predef._

object ReadDomainsListRequest {
  val aid = "ROX32411442894379981"

  val readDomainsList = exec(http("Get Domains List")
    .get(appDevURL + "/int/applications/" + aid +"/domains/")
    .headers(sentHeaders))
}
