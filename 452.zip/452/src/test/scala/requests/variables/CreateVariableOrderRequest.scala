/*
Request for testing RTSIVD-79, creating variable_order under
/int/applications/ROX37914912443862484/domains/ROX37914912443862547
*/
package requests.variables

import config.Config._
import io.gatling.core.Predef._
import io.gatling.http.Predef._
import scala.concurrent.duration._

object CreateVariableOrderRequest {
  val createVariableOrder = exec(http("Create variable_order")
    .put(appUatURL + "/int/applications/ROX37914912443862484/domains/ROX37914912443862547")
    .headers(sentHeaders)
    .body(StringBody(
      """{"variable_order": ["ROX37914912443862652","ROX37914912443862487",
        |"ROX37914912443862710","ROX37914912443862719","ROX37914912443862764",
        |"ROX37914912443862690","ROX37914912443862728","ROX37914912443862628",
        |"ROX37914912443862635","ROX37914912443862700"]}""".stripMargin)).asJson)
    .pause(5 seconds)
    .exec(http("Get variables ordered list")
      .get(appUatURL + "/int/applications/ROX37914912443862484/domains/ROX37914912443862547/variables")
      .headers(sentHeaders))
}
