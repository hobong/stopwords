package requests.variables

import config.Config._
import io.gatling.core.Predef._
import io.gatling.http.Predef._

object ReadDomainDetailsRequest {

  val readDomainDetails = exec(http("Read domain details")
      .get(appDevURL + "/int/applications/" + aid +"/domains/" + did)
      .headers(sentHeaders))
}
