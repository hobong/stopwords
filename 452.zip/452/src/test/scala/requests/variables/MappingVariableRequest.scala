package requests.variables

import config.Config._
import io.gatling.core.Predef._
import io.gatling.http.Predef._

object MappingVariableRequest {

  val domains = csv("data\\Domain.csv").circular

  val mappVariable = feed(domains).exec(http("Mapping terms to variables in a Domain")
    .post(appDevURL + "/int/applications/ROX37766304443831369/domains/${did}/variables/mappings")
    .headers(sentHeaders)
    .body(RawFileBody("bodies\\mappVariablesDateTime.json")).asJson)
}