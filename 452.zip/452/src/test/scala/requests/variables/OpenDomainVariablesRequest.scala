package requests.variables

object OpenDomainVariablesRequest {

}
