/*
Request used for testing endpoint Get all variables for given domain id
for task RTSIVD-79 is used with the following domain ids:
GetVariableOrderedFalseScenario - ROX37897632443853426
GetVariableOrderedTrueScenario - ROX37897632443853425
CreateVariableOrderScenario - ROX37897632443853427
 */

package requests.variables

import config.Config._
import io.gatling.core.Predef._
import io.gatling.http.Predef._

object GetVariablesListUnderDomainRequest {
  val getVariablesListUnderDomain = exec(http("Get variables list")
    .get(appUatURL + "/int/applications/ROX37897632443853423/domains/ROX37897632443853426/variables")
    .headers(sentHeaders)
    .check(status.is(200)))
}
