package requests.variables

import config.Config._
import io.gatling.core.Predef._
import io.gatling.http.Predef._

object ReadVariablesDetailsRequest {

  val readVariables = exec(http("Read variables Details")
    .get(appDevURL + "/int/applications/" + aid + "/domains/" + did + "/variables/${vid}")
    .headers(sentHeaders)
    .check(status.is(200)))
}
