/*
Request used for testing endpoint Get all variables for given domain id
for task RTSIVD-79 is used with the following domain ids:
CreateVariableOrder - ROX37914912443862547
getVariablesNonOrderedRequest - ROX37914912443863784
getVariablesOrderedRequest - ROX37914912443863769
application - ROX37914912443862484
 */

package requests.variables

import config.Config._
import io.gatling.core.Predef._
import io.gatling.http.Predef._

object GetVariablesListRequest {
  val getVariablesNonOrderedRequest = exec(http("Get list of variables when domain not ordered")
    .get(appDevURL + "/int/applications/ROX37676448443821184/domains/ROX37688544443821389/variables")
    .headers(sentHeaders)
    .check(status.is(200)))
    .exec(flushHttpCache)

  val getVariablesOrderedRequest = exec(http("Get list of variables when domain ordered")
    .get(appDevURL + "/int/applications/ROX37676448443821184/domains/ROX37688544443821389/variables")
    .headers(sentHeaders)
    .check(status.is(200)))
    .exec(flushHttpCache)
}