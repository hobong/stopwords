package requests.variables

import config.Config._
import io.gatling.core.Predef._
import io.gatling.http.Predef._

object CreateVariableRequest {

  val vid = ""

  val createVariable = exec(http("Create /variable")
      .post(appDevURL + "/int/applications/" + aid +"/domains/" + did + "/variables")
      .headers(sentHeaders)
      .body(StringBody(
        """{
          |"curation_policy_id": "ROX37724832443821963",
          |"data_type_constraint": "Data type constraint field",
          |"describing_concept_id": "ROX37643616443820651",
          |"label": "Date Time of Informed Consent",
          |"policy_id": "ROX37470816443785896",
          |"value_domain_id": "ROX1493304182069",
          |"value_domain_type": "application_terminology",
          |"variable_multiplicity_id": "ROX37717920443827943"}""".stripMargin)).asJson
      .check(jsonPath("$..id").find.saveAs("vid")))
}