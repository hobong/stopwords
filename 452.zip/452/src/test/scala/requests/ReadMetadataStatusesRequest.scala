package requests

import config.Config._
import io.gatling.core.Predef._
import io.gatling.http.Predef._

object ReadMetadataStatusesRequest {
  val readMetadataStatuses = exec(http("Read metadata statuses")
    .get(appDevURL + "/int/metadata/statuses")
    .headers(sentHeaders))
}
